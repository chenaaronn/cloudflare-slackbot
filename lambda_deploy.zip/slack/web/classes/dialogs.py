from slack_sdk.models.dialogs import DialogBuilder  # noqa

from slack import deprecation

deprecation.show_message(__name__, "slack_sdk.models.dialogs")
